import fitz  # PyMuPDF
import re
import json
import os
import argparse
import tempfile
from typing import Dict, Any, List, Tuple
import subprocess
import shutil
from pathlib import Path


class BillOfLadingExtractorWithOCR:
    """
    A class to extract structured data from Bill of Lading PDFs with OCR capabilities
    """
    
    def __init__(self, pdf_path: str, use_ocr: bool = False, ocr_lang: str = "eng"):
        """Initialize with the path to the PDF file"""
        self.pdf_path = pdf_path
        self.doc = fitz.open(pdf_path)
        self.extracted_data = {}
        self.use_ocr = use_ocr
        self.ocr_lang = ocr_lang
        self.ocr_text_cache = {}  # Cache OCR results by page
        
        # Check if tesseract is installed if OCR is requested
        if use_ocr:
            try:
                subprocess.run(["tesseract", "--version"], 
                               stdout=subprocess.PIPE, 
                               stderr=subprocess.PIPE, 
                               check=True)
            except (subprocess.SubprocessError, FileNotFoundError):
                raise RuntimeError("Tesseract OCR is not installed or not in PATH. Please install it to use OCR features.")
    
    def _get_page_text(self, page_num: int) -> str:
        """Get text from a page, using OCR if enabled"""
        if not self.use_ocr:
            return self.doc[page_num].get_text()
        
        # Check if we've already OCR'd this page
        if page_num in self.ocr_text_cache:
            return self.ocr_text_cache[page_num]
        
        # Extract text using OCR
        with tempfile.TemporaryDirectory() as temp_dir:
            # Save page as image
            page = self.doc[page_num]
            pix = page.get_pixmap(matrix=fitz.Matrix(300/72, 300/72))
            img_path = os.path.join(temp_dir, f"page_{page_num}.png")
            pix.save(img_path)
            
            # Run OCR
            txt_path = os.path.join(temp_dir, f"page_{page_num}")
            subprocess.run(
                ["tesseract", img_path, txt_path, "-l", self.ocr_lang],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=True
            )
            
            # Read OCR result
            with open(f"{txt_path}.txt", "r", encoding="utf-8") as f:
                text = f.read()
            
            # Cache the result
            self.ocr_text_cache[page_num] = text
            return text
    
    def extract_data(self) -> Dict[str, Any]:
        """Extract all relevant data from the Bill of Lading"""
        # Basic document info
        self.extracted_data["document_type"] = "Bill of Lading"
        self.extracted_data["filename"] = os.path.basename(self.pdf_path)
        
        # Extract key fields
        self._extract_bol_number()
        self._extract_shipper_info()
        self._extract_consignee_info()
        self._extract_notify_party_info()
        self._extract_vessel_info()
        self._extract_container_info()
        self._extract_dates()
        self._extract_ports()
        self._extract_cargo_details()
        
        return self.extracted_data
    
    def _extract_text_from_region(self, page_num: int, rect: Tuple[float, float, float, float]) -> str:
        """Extract text from a specific region of a page"""
        if not self.use_ocr:
            page = self.doc[page_num]
            words = page.get_text("words")
            text_in_region = [w[4] for w in words if fitz.Rect(w[0:4]).intersects(fitz.Rect(rect))]
            return " ".join(text_in_region)
        else:
            # For OCR, we need to extract just that region of the page as an image
            with tempfile.TemporaryDirectory() as temp_dir:
                page = self.doc[page_num]
                # Create a cropped pixmap for the region
                mat = fitz.Matrix(300/72, 300/72)  # 300 DPI resolution
                rect_obj = fitz.Rect(rect)
                pix = page.get_pixmap(matrix=mat, clip=rect_obj)
                
                img_path = os.path.join(temp_dir, f"region_{page_num}.png")
                pix.save(img_path)
                
                # Run OCR on the region
                txt_path = os.path.join(temp_dir, f"region_{page_num}")
                subprocess.run(
                    ["tesseract", img_path, txt_path, "-l", self.ocr_lang],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    check=True
                )
                
                # Read OCR result
                with open(f"{txt_path}.txt", "r", encoding="utf-8") as f:
                    text = f.read()
                
                return text.strip()
    
    def _extract_bol_number(self):
        """Extract the Bill of Lading number"""
        # Try different methods to find the BOL number
        
        # Method 1: Look for BOL number pattern in full text
        for page_num in range(min(2, len(self.doc))):  # Check first 2 pages
            text = self._get_page_text(page_num)
            bol_match = re.search(r'BILL OF LADING No\.?\s*([A-Z0-9]+)', text, re.IGNORECASE)
            if bol_match:
                self.extracted_data["bol_number"] = bol_match.group(1)
                return
        
        # Method 2: Try to find it in a specific region of the first page
        top_right_text = self._extract_text_from_region(0, (400, 20, 580, 60))
        bol_match = re.search(r'([A-Z]{5}\d{6,})', top_right_text)
        if bol_match:
            self.extracted_data["bol_number"] = bol_match.group(1)
            return
        
        # Method 3: Look for any alphanumeric string that looks like a BOL number
        for page_num in range(min(2, len(self.doc))):
            text = self._get_page_text(page_num)
            bol_candidates = re.findall(r'(?:BOL|B/L|BILL).*?([A-Z]{4,}\d{6,})', text, re.IGNORECASE)
            if bol_candidates:
                self.extracted_data["bol_number"] = bol_candidates[0]
                return
        
        self.extracted_data["bol_number"] = None
    
    def _extract_shipper_info(self):
        """Extract shipper information"""
        shipper_info = {"raw_text": ""}
        
        # Try different methods to find shipper info
        for page_num in range(min(2, len(self.doc))):
            text = self._get_page_text(page_num)
            
            # Method 1: Look for shipper section
            shipper_match = re.search(r'SHIPPER(?:\s*:|.*?)(?:\n|\r\n?)(.*?)(?:CONSIGNEE|NOTIFY PARTY)', 
                                     text, re.DOTALL | re.IGNORECASE)
            if shipper_match:
                shipper_section = shipper_match.group(1).strip()
                shipper_info["raw_text"] = shipper_section
                
                # Extract company name (usually the first line)
                lines = [line.strip() for line in shipper_section.split('\n') if line.strip()]
                if lines:
                    shipper_info["company_name"] = lines[0]
                    shipper_info["address"] = " ".join(lines[1:])
                break
        
        # Method 2: Try to extract from a specific region if method 1 failed
        if not shipper_info["raw_text"]:
            shipper_text = self._extract_text_from_region(0, (20, 80, 300, 120))
            shipper_info["raw_text"] = shipper_text
            
            # Try to parse the extracted text
            lines = [line.strip() for line in shipper_text.split('\n') if line.strip()]
            if lines:
                shipper_info["company_name"] = lines[0]
                shipper_info["address"] = " ".join(lines[1:])
        
        self.extracted_data["shipper"] = shipper_info
    
    def _extract_consignee_info(self):
        """Extract consignee information"""
        consignee_info = {"raw_text": ""}
        
        # Try different methods to find consignee info
        for page_num in range(min(2, len(self.doc))):
            text = self._get_page_text(page_num)
            
            # Method 1: Look for consignee section
            consignee_match = re.search(r'CONSIGNEE(?:\s*:|.*?)(?:\n|\r\n?)(.*?)(?:NOTIFY PARTY|VESSEL AND VOYAGE)', 
                                       text, re.DOTALL | re.IGNORECASE)
            if consignee_match:
                consignee_section = consignee_match.group(1).strip()
                consignee_info["raw_text"] = consignee_section
                
                # Extract company name and address
                lines = [line.strip() for line in consignee_section.split('\n') if line.strip()]
                if lines:
                    consignee_info["company_name"] = lines[0]
                    consignee_info["address"] = " ".join(lines[1:])
                break
        
        # Method 2: Try to extract from a specific region if method 1 failed
        if not consignee_info["raw_text"]:
            consignee_text = self._extract_text_from_region(0, (20, 130, 300, 180))
            consignee_info["raw_text"] = consignee_text
            
            # Try to parse the extracted text
            lines = [line.strip() for line in consignee_text.split('\n') if line.strip()]
            if lines:
                consignee_info["company_name"] = lines[0]
                consignee_info["address"] = " ".join(lines[1:])
        
        self.extracted_data["consignee"] = consignee_info
    
    def _extract_notify_party_info(self):
        """Extract notify party information"""
        notify_info = {"raw_text": ""}
        
        # Try different methods to find notify party info
        for page_num in range(min(2, len(self.doc))):
            text = self._get_page_text(page_num)
            
            # Method 1: Look for notify party section
            notify_match = re.search(r'NOTIFY PARTY(?:\s*:|.*?)(?:\n|\r\n?)(.*?)(?:VESSEL AND VOYAGE|PORT OF LOADING)', 
                                    text, re.DOTALL | re.IGNORECASE)
            if notify_match:
                notify_section = notify_match.group(1).strip()
                notify_info["raw_text"] = notify_section
                
                # Extract company name and address
                lines = [line.strip() for line in notify_section.split('\n') if line.strip()]
                if lines:
                    notify_info["company_name"] = lines[0]
                    notify_info["address"] = " ".join(lines[1:])
                break
        
        # Method 2: Try to extract from a specific region if method 1 failed
        if not notify_info["raw_text"]:
            notify_text = self._extract_text_from_region(0, (20, 180, 300, 240))
            notify_info["raw_text"] = notify_text
            
            # Try to parse the extracted text
            lines = [line.strip() for line in notify_text.split('\n') if line.strip()]
            if lines:
                notify_info["company_name"] = lines[0]
                notify_info["address"] = " ".join(lines[1:])
        
        self.extracted_data["notify_party"] = notify_info
    
    def _extract_vessel_info(self):
        """Extract vessel and voyage information"""
        vessel_info = {"raw_text": ""}
        
        # Try different methods to find vessel info
        for page_num in range(min(2, len(self.doc))):
            text = self._get_page_text(page_num)
            
            # Method 1: Look for vessel section with pattern
            vessel_match = re.search(r'VESSEL AND VOYAGE.*?([A-Z\s]+)/\s*([A-Z0-9]+)', text, re.IGNORECASE)
            if vessel_match:
                vessel_name = vessel_match.group(1).strip()
                voyage_number = vessel_match.group(2).strip()
                
                vessel_info = {
                    "name": vessel_name,
                    "voyage": voyage_number,
                    "raw_text": f"{vessel_name}/{voyage_number}"
                }
                break
            
            # Method 2: Look for vessel section with different pattern
            vessel_match2 = re.search(r'VESSEL.*?:?\s*([A-Z\s]+).*?VOYAGE.*?:?\s*([A-Z0-9]+)', 
                                     text, re.IGNORECASE | re.DOTALL)
            if vessel_match2:
                vessel_name = vessel_match2.group(1).strip()
                voyage_number = vessel_match2.group(2).strip()
                
                vessel_info = {
                    "name": vessel_name,
                    "voyage": voyage_number,
                    "raw_text": f"{vessel_name}/{voyage_number}"
                }
                break
        
        # Method 3: Try to extract from a specific region if methods 1 and 2 failed
        if not vessel_info.get("name"):
            vessel_text = self._extract_text_from_region(0, (20, 260, 150, 280))
            vessel_info["raw_text"] = vessel_text
            
            # Try to parse the extracted text
            vessel_match = re.search(r'([A-Z\s]+)/\s*([A-Z0-9]+)', vessel_text)
            if vessel_match:
                vessel_info["name"] = vessel_match.group(1).strip()
                vessel_info["voyage"] = vessel_match.group(2).strip()
        
        self.extracted_data["vessel"] = vessel_info
    
    def _extract_container_info(self):
        """Extract container information"""
        containers = []
        
        # Check all pages for container information
        for page_num in range(len(self.doc)):
            text = self._get_page_text(page_num)
            
            # Method 1: Look for container section
            container_section = None
            container_section_match = re.search(
                r'Container Numbers,?\s*Seal(.*?)(?:PLACE AND DATE OF ISSUE|SHIPPED ON BOARD|FREIGHT & CHARGES)', 
                text, re.DOTALL | re.IGNORECASE
            )
            if container_section_match:
                container_section = container_section_match.group(1).strip()
            
            # Method 2: Look for container numbers pattern
            if container_section:
                # Try to extract container numbers with standard pattern
                container_matches = re.finditer(r'([A-Z]{4}\d{7})', container_section)
                for match in container_matches:
                    container_number = match.group(1)
                    
                    # Try to find associated information
                    container_context = container_section[max(0, match.start() - 100):min(len(container_section), match.end() + 200)]
                    
                    # Extract seal number if available
                    seal_match = re.search(r'Seal\s*(?:Number|No\.?)?:?\s*(\w+)', container_context, re.IGNORECASE)
                    seal_number = seal_match.group(1) if seal_match else None
                    
                    # Extract package info if available
                    package_match = re.search(r'(\d+)\s+(?:PALLET|PALLETS|PKGS|PACKAGES)', container_context, re.IGNORECASE)
                    package_count = package_match.group(1) if package_match else None
                    
                    # Extract weight if available
                    weight_match = re.search(r'(\d+[\.,]\d+)\s*(?:kgs|kg)', container_context, re.IGNORECASE)
                    weight = weight_match.group(1) if weight_match else None
                    
                    containers.append({
                        "container_number": container_number,
                        "seal_number": seal_number,
                        "package_count": package_count,
                        "weight": weight,
                        "context": container_context
                    })
            
            # Method 3: Look for container numbers anywhere in the text
            if not containers:
                container_matches = re.finditer(r'([A-Z]{4}\d{7})', text)
                for match in container_matches:
                    container_number = match.group(1)
                    
                    # Try to find associated information
                    container_context = text[max(0, match.start() - 100):min(len(text), match.end() + 200)]
                    
                    # Extract seal number if available
                    seal_match = re.search(r'Seal\s*(?:Number|No\.?)?:?\s*(\w+)', container_context, re.IGNORECASE)
                    seal_number = seal_match.group(1) if seal_match else None
                    
                    # Extract package info if available
                    package_match = re.search(r'(\d+)\s+(?:PALLET|PALLETS|PKGS|PACKAGES)', container_context, re.IGNORECASE)
                    package_count = package_match.group(1) if package_match else None
                    
                    # Extract weight if available
                    weight_match = re.search(r'(\d+[\.,]\d+)\s*(?:kgs|kg)', container_context, re.IGNORECASE)
                    weight = weight_match.group(1) if weight_match else None
                    
                    containers.append({
                        "container_number": container_number,
                        "seal_number": seal_number,
                        "package_count": package_count,
                        "weight": weight,
                        "context": container_context
                    })
        
        self.extracted_data["containers"] = containers
    
    def _extract_dates(self):
        """Extract relevant dates"""
        # Check all pages for date information
        for page_num in range(len(self.doc)):
            text = self._get_page_text(page_num)
            
            # Extract issue date
            issue_date_match = re.search(
                r'(?:PLACE AND DATE OF ISSUE|DATE OF ISSUE).*?(\d{1,2}[-\s./][A-Za-z]{3}[-\s./]\d{2,4}|\d{1,2}[-\s./]\d{1,2}[-\s./]\d{2,4})', 
                text, re.DOTALL | re.IGNORECASE
            )
            if issue_date_match and "issue_date" not in self.extracted_data:
                self.extracted_data["issue_date"] = issue_date_match.group(1).strip()
            
            # Extract shipped on board date
            shipped_date_match = re.search(
                r'(?:SHIPPED ON BOARD DATE|SHIPPED ON BOARD).*?(\d{1,2}[-\s./][A-Za-z]{3}[-\s./]\d{2,4}|\d{1,2}[-\s./]\d{1,2}[-\s./]\d{2,4})', 
                text, re.DOTALL | re.IGNORECASE
            )
            if shipped_date_match and "shipped_date" not in self.extracted_data:
                self.extracted_data["shipped_date"] = shipped_date_match.group(1).strip()
    
    def _extract_ports(self):
        """Extract port information"""
        # Check all pages for port information
        for page_num in range(len(self.doc)):
            text = self._get_page_text(page_num)
            
            # Extract port of loading
            pol_match = re.search(r'PORT OF LOADING.*?:?\s*([A-Za-z\s,.]+)', text, re.IGNORECASE)
            if pol_match and "port_of_loading" not in self.extracted_data:
                self.extracted_data["port_of_loading"] = pol_match.group(1).strip()
            
            # Extract port of discharge
            pod_match = re.search(r'PORT OF DISCHARGE.*?:?\s*([A-Za-z\s,.]+)', text, re.IGNORECASE)
            if pod_match and "port_of_discharge" not in self.extracted_data:
                self.extracted_data["port_of_discharge"] = pod_match.group(1).strip()
            
            # Extract place of receipt
            por_match = re.search(r'PLACE OF RECEIPT.*?:?\s*([A-Za-z\s,.]+)', text, re.IGNORECASE)
            if por_match and "place_of_receipt" not in self.extracted_data:
                self.extracted_data["place_of_receipt"] = por_match.group(1).strip()
            
            # Extract place of delivery
            delivery_match = re.search(r'PLACE OF DELIVERY.*?:?\s*([A-Za-z\s,.]+)', text, re.IGNORECASE)
            if delivery_match and "place_of_delivery" not in self.extracted_data:
                self.extracted_data["place_of_delivery"] = delivery_match.group(1).strip()
    
    def _extract_cargo_details(self):
        """Extract cargo details"""
        cargo_details = {}
        
        # Check all pages for cargo details
        for page_num in range(len(self.doc)):
            text = self._get_page_text(page_num)
            
            # Extract package count
            package_match = re.search(r'Total\s*(?:Items|Packages|Pkgs)?\s*:?\s*(\d+)', text, re.IGNORECASE)
            if package_match and "package_count" not in cargo_details:
                cargo_details["package_count"] = package_match.group(1)
            
            # Extract gross weight
            weight_match = re.search(r'(?:Total\s*)?Gross\s*Weight\s*:?\s*(\d+[\.,]\d+)\s*(?:Kgs|kg)', text, re.IGNORECASE)
            if weight_match and "gross_weight_kg" not in cargo_details:
                cargo_details["gross_weight_kg"] = weight_match.group(1)
            
            # Extract description
            desc_match = re.search(r'Description of Packages and Goods.*?(?:\n|\r\n?)(.*?)(?:Gross|Weight|Total|FREIGHT)', text, re.DOTALL | re.IGNORECASE)
            if desc_match and "description" not in cargo_details:
                description = desc_match.group(1).strip()
                # Clean up the description
                description = re.sub(r'\s+', ' ', description)
                cargo_details["description"] = description
        
        self.extracted_data["cargo"] = cargo_details
    
    def save_to_json(self, output_path: str = None) -> str:
        """Save the extracted data to a JSON file"""
        if not output_path:
            # Use the same filename but with .json extension
            base_name = os.path.splitext(os.path.basename(self.pdf_path))[0]
            output_path = f"{base_name}.json"
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.extracted_data, f, indent=2, ensure_ascii=False)
        
        return output_path


def main():
    parser = argparse.ArgumentParser(description='Extract data from Bill of Lading PDFs with OCR support')
    parser.add_argument('pdf_path', help='Path to the PDF file')
    parser.add_argument('--output', '-o', help='Output JSON file path')
    parser.add_argument('--ocr', action='store_true', help='Use OCR for text extraction')
    parser.add_argument('--lang', default='eng', help='OCR language (default: eng)')
    
    args = parser.parse_args()
    
    # Check if the PDF file exists
    if not os.path.isfile(args.pdf_path):
        print(f"Error: PDF file '{args.pdf_path}' not found.")
        return 1
    
    try:
        extractor = BillOfLadingExtractorWithOCR(args.pdf_path, use_ocr=args.ocr, ocr_lang=args.lang)
        data = extractor.extract_data()
        output_file = extractor.save_to_json(args.output)
        
        print(f"Extracted data saved to {output_file}")
        print(f"Summary of extracted data:")
        print(f"BOL Number: {data.get('bol_number', 'Not found')}")
        print(f"Shipper: {data.get('shipper', {}).get('company_name', 'Not found')}")
        print(f"Consignee: {data.get('consignee', {}).get('company_name', 'Not found')}")
        print(f"Vessel: {data.get('vessel', {}).get('name', 'Not found')}")
        print(f"Containers: {len(data.get('containers', []))}")
        return 0
    
    except Exception as e:
        print(f"Error: {str(e)}")
        return 1


if __name__ == "__main__":
    exit(main()) 